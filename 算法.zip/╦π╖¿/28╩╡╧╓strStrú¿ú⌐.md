暴力解法遍历 （超时）

```
class Solution:
    def strStr(self, haystack: str, needle: str) -> int:
        hay=0
        sta=0
        nh=len(haystack)
        nn=len(needle)
        if nh<nn:
            return -1
        if needle=="":
            return 0
        i=0
        for i in range(nh-nn+1): 
            while haystack[i]==needle[sta]:#试一试 可以加sta不存在的条件
                i+=1
                sta+=1
                if sta==nn:
                    return i-nn
            if sta!=0:sta=0
            else:i+=1

        return -1
```

