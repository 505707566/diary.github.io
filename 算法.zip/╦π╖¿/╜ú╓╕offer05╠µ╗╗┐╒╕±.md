```
class Solution:
    def replaceSpace(self, s: str) -> str:
        ans=[]
        for i in s:
            if i==' ':ans.append('%20')
            else:ans.append(i)
        return ''.join(ans)
```

注意用新的数组来遍历原字符串 来填，而不是直接替换