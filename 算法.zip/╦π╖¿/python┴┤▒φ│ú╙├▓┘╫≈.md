创建链表，用deque

a=deque()



添加元素：

尾部用 .appen()

指定位置插入用 .insert()



访问元素：



![image-20211217112533297](https://s2.loli.net/2021/12/17/B9E3Vv824dUouYL.png)





搜索元素：



用 .index() 来返回索引



更新元素：

![image-20211217112648307](https://s2.loli.net/2021/12/17/3DSc5LHICNaekqy.png)





删除元素：



删除具体值

.remove() #括号里是具体值

删除指定索引

del linkedlist[2]



获取长度：

len()

